import cv2
import os
import numpy as np

dataPath = "./data"
listaPersonas = os.listdir(dataPath)
print('Lista de personas :', listaPersonas)

labels = []
facesData = []
label = 0

print('leyendo las imágenes...')

for personDir in listaPersonas:
    personPath = os.path.join(dataPath, personDir)
    for fileName in os.listdir(personPath):
        print('rostros:', fileName, '/', personDir + '/' + fileName)
        imagePath = os.path.join(personPath, fileName)
        img = cv2.imread(imagePath, 0)
        if img is None:
            print("No se pudo leer la imagen:", imagePath)
            continue
        facesData.append(img)
        labels.append(label)
    label += 1

# Verifica que hay suficientes datos para entrenar
if len(facesData) == 0:
    print("No se encontraron imágenes para entrenar.")
else:
    face_recognizer = cv2.face.LBPHFaceRecognizer_create()
    print("Entrenando modelo...")
    face_recognizer.train(facesData, np.array(labels))
    face_recognizer.write("modelo.xml")
    print("Modelo almacenado")